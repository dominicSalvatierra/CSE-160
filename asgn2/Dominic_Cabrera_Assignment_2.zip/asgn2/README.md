.css files:
- N/A

.js modifications:
- Additional Functionality in my .js file:
  - addActionsForHtmlUI(): grab slider info for animation speed. High-level interface in HTML

shape files:
- trianglePrism.js: represents non-cube primitive
- Cube.js

Shift-Key: flaps the wings and swivels the head of my penguin over a 2 second period. 

Resources:
  - 2020 CSE 160 Youtube Helper Videos: I watched all the videos to set up my code.
  - ChatGPT: 
    - to streamline my understanding of HTML and Javascript. I am still fairly new to these languages (first time using these languages regularly), so I am using ChatGPT to assist my understanding. This was especially useful for helping me build and understand my mouse interaction functions. 
  